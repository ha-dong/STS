package springbootboard.member.service;

import springbootboard.member.entity.Member;

public interface MemberService {
	
	public abstract Member getMember(Member member);

}
